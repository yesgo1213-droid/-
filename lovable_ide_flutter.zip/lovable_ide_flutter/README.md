# Lovable IDE (Flutter)

محرر أكواد على شكل VS Code للأندرويد، يجمع ميزات Acode + Spck.

## الميزات
- محرر Monaco داخل WebView (نفس محرك VS Code) — IntelliSense + Themes
- فتح/حفظ/إنشاء الملفات
- تشغيل HTML / JS / TypeScript / Python (Pyodide داخل WebView)
- واجهة داكنة VS Code-like
- يدعم لغات: js, ts, html, css, json, md, py, dart, java, kt, php, xml

## البناء على Termux
```bash
pkg install -y git openjdk-17 wget unzip
# ثبّت Flutter (proot-distro ubuntu موصى به):
proot-distro install ubuntu
proot-distro login ubuntu
apt update && apt install -y git curl unzip xz-utils zip libglu1-mesa openjdk-17-jdk
git clone https://github.com/flutter/flutter.git -b stable ~/flutter
export PATH="$PATH:~/flutter/bin"
# Android command-line tools + SDK (sdkmanager) + accept-licenses
# ثم:
cd lovable_ide_flutter
flutter pub get
flutter build apk --release
# الناتج: build/app/outputs/flutter-apk/app-release.apk
```

## البناء على جهاز عادي (أسرع)
```bash
flutter create . --project-name lovable_ide --platforms=android
# (يولّد ملفات Gradle wrapper المفقودة)
flutter pub get
flutter build apk --release
```
> ملاحظة: لم أضف `gradle-wrapper.jar` و`MainActivity.kt` لأنّ `flutter create .` ينشئها تلقائياً عند أول بناء — هذه أنظف طريقة.
