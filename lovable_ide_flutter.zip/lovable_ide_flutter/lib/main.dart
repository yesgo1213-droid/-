import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  if (WebViewPlatform.instance is AndroidWebViewPlatform) {
    AndroidWebViewController.enableDebugging(true);
  }
  runApp(const LovableIDEApp());
}

class LovableIDEApp extends StatelessWidget {
  const LovableIDEApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lovable IDE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF1E1E1E),
      ),
      home: const EditorPage(),
    );
  }
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late final WebViewController _controller;
  String _currentFile = 'untitled.js';
  String _language = 'javascript';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF1E1E1E))
      ..addJavaScriptChannel('Flutter', onMessageReceived: _onJsMessage)
      ..loadFlutterAsset('assets/web/editor.html');
  }

  void _onJsMessage(JavaScriptMessage msg) async {
    try {
      final data = jsonDecode(msg.message);
      if (data['type'] == 'save') {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('file:$_currentFile', data['content']);
      }
    } catch (_) {}
  }

  Future<String> _getEditorValue() async {
    final v = await _controller.runJavaScriptReturningResult('window.getValue()');
    var s = v.toString();
    if (s.startsWith('"')) s = jsonDecode(s);
    return s;
  }

  Future<void> _newFile() async {
    final name = await _prompt('اسم الملف الجديد', 'file.js');
    if (name == null || name.isEmpty) return;
    _currentFile = name;
    _language = _detectLang(name);
    await _controller.runJavaScript("window.setValue('', '$_language')");
    setState(() {});
  }

  Future<void> _openFile() async {
    final res = await FilePicker.platform.pickFiles(withData: true);
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    final content = String.fromCharCodes(f.bytes ?? []);
    _currentFile = f.name;
    _language = _detectLang(f.name);
    final esc = jsonEncode(content);
    await _controller.runJavaScript("window.setValue($esc, '$_language')");
    setState(() {});
  }

  Future<void> _saveFile() async {
    final content = await _getEditorValue();
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$_currentFile');
    await file.writeAsString(content);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم الحفظ: ${file.path}')),
      );
    }
  }

  Future<void> _runCode() async {
    final content = await _getEditorValue();
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => RunnerPage(
      code: content, language: _language,
    )));
  }

  Future<String?> _prompt(String title, String initial) async {
    final c = TextEditingController(text: initial);
    return showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('موافق')),
      ],
    ));
  }

  String _detectLang(String name) {
    final ext = name.split('.').last.toLowerCase();
    return {
      'js': 'javascript', 'ts': 'typescript', 'html': 'html', 'css': 'css',
      'json': 'json', 'md': 'markdown', 'py': 'python', 'dart': 'dart',
      'java': 'java', 'kt': 'kotlin', 'php': 'php', 'xml': 'xml',
    }[ext] ?? 'plaintext';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF252526),
        title: Text(_currentFile, style: const TextStyle(fontSize: 14)),
        actions: [
          IconButton(icon: const Icon(Icons.note_add), onPressed: _newFile, tooltip: 'جديد'),
          IconButton(icon: const Icon(Icons.folder_open), onPressed: _openFile, tooltip: 'فتح'),
          IconButton(icon: const Icon(Icons.save), onPressed: _saveFile, tooltip: 'حفظ'),
          IconButton(icon: const Icon(Icons.play_arrow, color: Colors.greenAccent), onPressed: _runCode, tooltip: 'تشغيل'),
        ],
      ),
      body: WebViewWidget(controller: _controller),
      bottomNavigationBar: Container(
        height: 24, color: const Color(0xFF007ACC),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        alignment: Alignment.centerLeft,
        child: Text('$_language  •  Lovable IDE', style: const TextStyle(fontSize: 11)),
      ),
    );
  }
}

class RunnerPage extends StatefulWidget {
  final String code; final String language;
  const RunnerPage({super.key, required this.code, required this.language});
  @override
  State<RunnerPage> createState() => _RunnerPageState();
}

class _RunnerPageState extends State<RunnerPage> {
  late final WebViewController _c;
  @override
  void initState() {
    super.initState();
    _c = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted);
    _load();
  }

  void _load() {
    String html;
    if (widget.language == 'html') {
      html = widget.code;
    } else if (widget.language == 'javascript' || widget.language == 'typescript') {
      html = '''<!doctype html><html><body style="background:#1e1e1e;color:#ddd;font-family:monospace;padding:10px">
<pre id="out"></pre><script>
const out=document.getElementById('out');
const log=(...a)=>out.textContent+=a.join(' ')+'\\n';
console.log=log; console.error=log; console.warn=log;
try{${widget.code}}catch(e){log('Error: '+e.message)}
</script></body></html>''';
    } else if (widget.language == 'python') {
      final esc = jsonEncode(widget.code);
      html = '''<!doctype html><html><body style="background:#1e1e1e;color:#ddd;font-family:monospace;padding:10px">
<pre id="out">جارٍ تحميل Python...</pre>
<script src="https://cdn.jsdelivr.net/pyodide/v0.26.2/full/pyodide.js"></script>
<script>
(async()=>{const out=document.getElementById('out');
const py=await loadPyodide();out.textContent='';
py.setStdout({batched:(s)=>out.textContent+=s+'\\n'});
py.setStderr({batched:(s)=>out.textContent+=s+'\\n'});
try{await py.runPythonAsync($esc)}catch(e){out.textContent+=e.message}})();
</script></body></html>''';
    } else {
      html = '<html><body style="background:#1e1e1e;color:#ddd;padding:20px">لا يوجد runner للغة ${widget.language}</body></html>';
    }
    _c.loadHtmlString(html);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Output'), backgroundColor: const Color(0xFF252526)),
      body: WebViewWidget(controller: _c),
    );
  }
}
